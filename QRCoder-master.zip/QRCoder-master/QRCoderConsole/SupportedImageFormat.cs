﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QRCoderConsole
{
    public enum SupportedImageFormat
    {
        Png,
        Jpg,
        Gif,
        Bmp,
        Tiff,
        Svg,
        Xaml,
        Ps,
        Eps,
    }
}
