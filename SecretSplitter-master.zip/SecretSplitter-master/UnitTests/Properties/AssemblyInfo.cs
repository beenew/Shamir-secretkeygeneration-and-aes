﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("UnitTests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Moserware")]
[assembly: AssemblyProduct("UnitTests")]
[assembly: AssemblyCopyright("Copyright © Jeff Moser 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("75779006-1da7-43a7-b902-5bd45b192a3c")]

[assembly: AssemblyVersion(Moserware.Security.Cryptography.Versioning.VersionInfo.CurrentVersionString)]
[assembly: AssemblyFileVersion(Moserware.Security.Cryptography.Versioning.VersionInfo.CurrentVersionString)]