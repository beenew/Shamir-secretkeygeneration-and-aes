﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ssss")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Moserware")]
[assembly: AssemblyProduct("ssss")]
[assembly: AssemblyCopyright("Copyright © Jeff Moser 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("32579f1c-11c0-4c46-85e1-8266dc9d7c1d")]

[assembly: AssemblyVersion(Moserware.Security.Cryptography.Versioning.VersionInfo.CurrentVersionString)]
[assembly: AssemblyFileVersion(Moserware.Security.Cryptography.Versioning.VersionInfo.CurrentVersionString)]