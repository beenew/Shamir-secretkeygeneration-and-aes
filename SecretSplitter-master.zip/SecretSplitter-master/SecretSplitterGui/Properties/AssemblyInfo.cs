﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SecretSplitter GUI")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Moserware")]
[assembly: AssemblyProduct("SecretSplitter GUI")]
[assembly: AssemblyCopyright("Copyright © Jeff Moser 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("dc9a7679-f6c7-4f2e-887c-fae473bce754")]
[assembly: AssemblyVersion(Moserware.Security.Cryptography.Versioning.VersionInfo.CurrentVersionString)]
[assembly: AssemblyFileVersion(Moserware.Security.Cryptography.Versioning.VersionInfo.CurrentVersionString)]
